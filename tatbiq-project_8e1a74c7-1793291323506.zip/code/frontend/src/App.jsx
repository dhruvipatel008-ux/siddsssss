import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import toast from 'react-hot-toast';
import appData from './data/app-data.json';
import { useSupabase } from './hooks/useSupabase';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import ChallengePage from './pages/ChallengePage';
import GalleryPage from './pages/GalleryPage';

const AppContext = createContext(null);

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}

function AppProvider({ children }) {
  const dataLayer = useSupabase();
  const dataLayerRef = useRef(dataLayer);
  const [selectedEmoji, setSelectedEmoji] = useState(null);
  const [mode, setMode] = useState('watch');
  const [phase, setPhase] = useState('idle');
  const [timeLeft, setTimeLeft] = useState(15);
  const [strokes, setStrokes] = useState([]);
  const [muted, setMuted] = useState(false);
  const [drawings, setDrawings] = useState([]);
  const [ideas, setIdeas] = useState(appData.seedIdeas);
  const [voted, setVoted] = useState([]);
  const [best, setBest] = useState({});

  useEffect(() => {
    dataLayerRef.current = dataLayer;
  }, [dataLayer]);

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const [loadedDrawings, loadedIdeas, loadedVoted, loadedMuted, loadedBest] = await Promise.all([
          dataLayerRef.current.getDrawings(),
          dataLayerRef.current.getIdeas(),
          dataLayerRef.current.getVoted(),
          dataLayerRef.current.getMuted(),
          dataLayerRef.current.getBest()
        ]);
        if (!mounted) return;
        setDrawings(Array.isArray(loadedDrawings) ? loadedDrawings : []);
        setIdeas(Array.isArray(loadedIdeas) ? loadedIdeas : []);
        setVoted(Array.isArray(loadedVoted) ? loadedVoted : []);
        setMuted(Boolean(loadedMuted));
        setBest(loadedBest || {});
      } catch (error) {
        toast.error('Load failed: ' + error.message);
      }
    }
    load();
    return () => {
      mounted = false;
    };
  }, []);

  const startChallenge = (emoji, nextMode) => {
    setSelectedEmoji(emoji);
    setMode(nextMode);
    setPhase('intro');
    setTimeLeft(15);
    setStrokes([]);
  };

  const setMutedPreference = async (value) => {
    const next = await dataLayerRef.current.setMuted(value);
    setMuted(next);
  };

  const saveDrawing = async (drawing) => {
    const next = await dataLayerRef.current.saveDrawing(drawing);
    setDrawings(Array.isArray(next) ? next : []);
  };

  const deleteDrawing = async (id) => {
    const next = await dataLayerRef.current.deleteDrawing(id);
    setDrawings(Array.isArray(next) ? next : []);
  };

  const addIdea = async (text) => {
    const next = await dataLayerRef.current.addIdea(text);
    setIdeas(Array.isArray(next) ? next : []);
  };

  const voteIdea = async (id) => {
    const result = await dataLayerRef.current.voteIdea(id);
    setIdeas(Array.isArray(result.ideas) ? result.ideas : []);
    setVoted(Array.isArray(result.voted) ? result.voted : []);
  };

  const saveBest = async (emojiId, value) => {
    const next = await dataLayerRef.current.saveBest(emojiId, value);
    setBest(next || {});
  };

  const value = useMemo(
    () => ({
      selectedEmoji,
      setSelectedEmoji,
      mode,
      setMode,
      phase,
      setPhase,
      timeLeft,
      setTimeLeft,
      strokes,
      setStrokes,
      muted,
      setMutedPreference,
      drawings,
      ideas,
      voted,
      best,
      startChallenge,
      saveDrawing,
      deleteDrawing,
      addIdea,
      voteIdea,
      saveBest
    }),
    [selectedEmoji, mode, phase, timeLeft, strokes, muted, drawings, ideas, voted, best]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/challenge" element={<ChallengePage />} />
            <Route path="/gallery" element={<GalleryPage />} />
          </Route>
        </Routes>
      </AppProvider>
    </BrowserRouter>
  );
}
