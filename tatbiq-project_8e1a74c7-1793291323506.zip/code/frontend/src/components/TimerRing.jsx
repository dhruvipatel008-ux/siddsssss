import { motion, useReducedMotion } from 'framer-motion';

export default function TimerRing({ timeLeft, size = 160 }) {
  const reduceMotion = useReducedMotion();
  const total = 15;
  const radius = 66;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.max(0, Math.min(1, timeLeft / total));
  const color = timeLeft <= 3 ? '#FF4D4D' : timeLeft <= 7 ? '#FF9F1C' : '#2BD17E';

  return (
    <motion.div
      className="relative grid place-items-center"
      animate={
        timeLeft <= 3 && timeLeft > 0 && !reduceMotion
          ? { scale: [1, 1.12, 1], x: [0, -2, 2, 0] }
          : { scale: 1, x: 0 }
      }
      transition={{ duration: 0.45, repeat: timeLeft <= 3 && timeLeft > 0 ? Infinity : 0 }}
      style={{ width: size, height: size }}
      aria-label={`${Math.ceil(timeLeft)} seconds remaining`}
    >
      <svg viewBox="0 0 160 160" className="absolute inset-0 -rotate-90">
        <circle cx="80" cy="80" r={radius} fill="#FFFFFF" stroke="#1B1B1F" strokeWidth="3" />
        <circle cx="80" cy="80" r={radius} fill="none" stroke="#FFEFC2" strokeWidth="14" />
        <motion.circle
          cx="80"
          cy="80"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={circumference}
          animate={{ strokeDashoffset: circumference * (1 - progress) }}
          transition={{ duration: 0.2, ease: 'linear' }}
        />
      </svg>
      <span className="relative font-heading text-6xl text-ink drop-shadow-[2px_2px_0_#FFD23F]">
        {Math.ceil(timeLeft)}
      </span>
    </motion.div>
  );
}
