import { AnimatePresence, motion } from 'framer-motion';
import { GalleryHorizontal, Lightbulb, Menu, PencilLine, Play, X } from 'lucide-react';
import { useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

const navItems = [
  { to: '/', label: 'Play', icon: Play },
  { to: '/gallery', label: 'Gallery', icon: GalleryHorizontal },
  { to: '/#ideas', label: 'Ideas', icon: Lightbulb }
];

export default function Layout() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';

  const goIdeas = (event) => {
    event.preventDefault();
    setOpen(false);
    if (location.pathname !== '/') {
      navigate('/');
      window.setTimeout(() => document.getElementById('ideas')?.scrollIntoView({ behavior: 'smooth' }), 80);
    } else {
      document.getElementById('ideas')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const renderNav = (mobile = false) =>
    navItems.map((item) => {
      const Icon = item.icon;
      if (item.label === 'Ideas') {
        return (
          <a
            key={item.label}
            href="/#ideas"
            onClick={goIdeas}
            className={`nav-pill ${mobile ? 'justify-start' : ''}`}
          >
            <Icon size={18} /> {item.label}
          </a>
        );
      }
      return (
        <NavLink
          key={item.to}
          to={item.to}
          onClick={() => setOpen(false)}
          className={({ isActive }) => `nav-pill ${isActive ? 'bg-sunburst' : ''} ${mobile ? 'justify-start' : ''}`}
        >
          <Icon size={18} /> {item.label}
        </NavLink>
      );
    });

  return (
    <div className="min-h-screen bg-warmPaper font-body text-ink">
      <header className={`fixed left-0 right-0 top-0 z-40 ${isHome ? 'bg-white/10' : 'bg-warmPaper/75'} backdrop-blur-md`}>
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <NavLink to="/" className="group flex items-center gap-3 focus:outline-none focus:ring-4 focus:ring-sunburst/50">
            <span className="grid h-12 w-12 place-items-center rounded-2xl border-[3px] border-ink bg-redMarker text-white shadow-[4px_4px_0_#1B1B1F] transition group-hover:-translate-y-1">
              <PencilLine size={26} strokeWidth={3} />
            </span>
            <span className="font-heading text-3xl leading-none text-ink">Emoji Draw</span>
          </NavLink>

          <nav className="hidden items-center gap-3 md:flex">{renderNav()}</nav>

          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            className="grid h-12 w-12 place-items-center rounded-full border-[3px] border-ink bg-paperWhite shadow-[3px_3px_0_#1B1B1F] transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-sunburst/50 md:hidden"
            aria-label="Open navigation"
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>

        <AnimatePresence>
          {open ? (
            <motion.nav
              className="mx-4 mb-4 grid gap-3 rounded-2xl border-[3px] border-ink bg-paperWhite p-3 shadow-[4px_4px_0_#1B1B1F] md:hidden"
              initial={{ y: -12, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -12, opacity: 0 }}
            >
              {renderNav(true)}
            </motion.nav>
          ) : null}
        </AnimatePresence>
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="border-t-[3px] border-ink bg-ink py-10 text-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
          <div>
            <p className="font-heading text-3xl">Emoji Draw Challenge</p>
            <p className="font-bold text-white/70">A 15-second Sharpie Sunrise drawing sprint.</p>
          </div>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="btn-primary w-fit bg-sunburst text-ink"
          >
            Back to top
          </button>
        </div>
      </footer>

      <Toaster
        position="bottom-center"
        toastOptions={{
          style: {
            border: '3px solid #1B1B1F',
            borderRadius: '18px',
            boxShadow: '4px 4px 0 #1B1B1F',
            fontWeight: 900
          }
        }}
      />
    </div>
  );
}
