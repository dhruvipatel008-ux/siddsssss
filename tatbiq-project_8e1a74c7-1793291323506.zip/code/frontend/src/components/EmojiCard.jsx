import { motion } from 'framer-motion';
import { Check, Gauge, Trophy } from 'lucide-react';

export default function EmojiCard({ emoji, selected, bestTime, onSelect }) {
  return (
    <motion.button
      type="button"
      onClick={() => onSelect(emoji)}
      className={`sticker-card group w-full p-5 text-left transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-sunburst/50 ${
        selected ? 'bg-sunburst' : 'bg-paperWhite'
      }`}
      whileHover={{ x: -2, y: -2 }}
      whileTap={{ scale: 0.96, rotate: -1 }}
      aria-pressed={selected}
    >
      <div className="flex items-start justify-between gap-4">
        <motion.div
          className="grid h-24 w-24 shrink-0 place-items-center rounded-full border-[3px] border-ink text-center font-heading text-4xl text-ink shadow-[3px_3px_0_#1B1B1F]"
          style={{ backgroundColor: emoji.blob }}
          whileHover={{ y: -6 }}
          transition={{ type: 'spring', stiffness: 320, damping: 18 }}
        >
          {emoji.preview}
        </motion.div>
        <div className="grid h-9 w-9 place-items-center rounded-full border-[3px] border-ink bg-white">
          {selected ? <Check size={20} strokeWidth={3} /> : <Gauge size={20} strokeWidth={3} />}
        </div>
      </div>

      <h3 className="mt-5 font-heading text-3xl leading-none text-ink">{emoji.name}</h3>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="rounded-full border-2 border-ink bg-warmPaper px-3 py-1 text-sm font-extrabold text-ink">
          {emoji.difficulty}
        </span>
        <span className="inline-flex items-center gap-1 rounded-full border-2 border-ink bg-white px-3 py-1 text-sm font-extrabold text-ink">
          <Trophy size={15} />
          {bestTime ? `${bestTime.toFixed(1)}s best` : 'No best yet'}
        </span>
      </div>
    </motion.button>
  );
}
