import { AnimatePresence, motion } from 'framer-motion';
import { Brush, Check, Eye, EyeOff, RotateCcw, Trash2, X } from 'lucide-react';
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';

const colors = ['#1B1B1F', '#FF4D4D', '#2D7FF9', '#2BD17E', '#FF9F1C', '#9B5DE5'];
const sizes = [4, 8, 14];

function drawPath(ctx, points, color, width, canvas) {
  if (!points || points.length < 2) return;
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(points[0][0] * canvas.width, points[0][1] * canvas.height);
  for (let index = 1; index < points.length; index += 1) {
    ctx.lineTo(points[index][0] * canvas.width, points[index][1] * canvas.height);
  }
  ctx.stroke();
  ctx.restore();
}

function redrawUserStrokes(canvas, strokes, ghostGuide, emoji) {
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  if (ghostGuide) {
    ctx.globalAlpha = 0.15;
    emoji.strokes.forEach((stroke) => drawPath(ctx, stroke.points, stroke.color, stroke.width, canvas));
    ctx.globalAlpha = 1;
  }

  strokes.forEach((stroke) => drawPath(ctx, stroke.points, stroke.color, stroke.width, canvas));
}

function ClearConfirm({ open, onCancel, onConfirm }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      if (event.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onCancel]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-40 grid place-items-center bg-ink/50 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label="Clear drawing confirmation"
        >
          <motion.div
            className="sticker-card max-w-sm bg-paperWhite p-6 text-center"
            initial={{ scale: 0.85, rotate: -2 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0.9, opacity: 0 }}
          >
            <h3 className="font-heading text-4xl text-ink">Clear your drawing?</h3>
            <p className="mt-2 font-bold text-ink/70">This wipes the paper, but you can start fresh right away.</p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button type="button" onClick={onCancel} className="btn-secondary justify-center bg-white">
                <X size={18} /> Cancel
              </button>
              <button type="button" onClick={onConfirm} className="btn-primary justify-center">
                <Check size={18} /> Confirm
              </button>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

const DrawingStage = forwardRef(function DrawingStage(
  { emoji, mode, phase, resetKey, onFinishEarly, onStrokesChange },
  ref
) {
  const canvasRef = useRef(null);
  const wrapperRef = useRef(null);
  const rafRef = useRef(null);
  const activeStrokeRef = useRef(null);
  const startedAtRef = useRef(0);
  const [userStrokes, setUserStrokes] = useState([]);
  const [currentColor, setCurrentColor] = useState('#1B1B1F');
  const [currentSize, setCurrentSize] = useState(8);
  const [ghostGuide, setGhostGuide] = useState(true);
  const [marker, setMarker] = useState({ x: 50, y: 50, visible: false });
  const [confirmOpen, setConfirmOpen] = useState(false);

  useImperativeHandle(ref, () => ({
    getDataUrl: () => canvasRef.current?.toDataURL('image/png') || ''
  }));

  const setupCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parent = wrapperRef.current;
    const rect = parent.getBoundingClientRect();
    const width = Math.max(320, Math.floor(rect.width - 24));
    const height = Math.floor(width * 0.72);
    const ratio = window.devicePixelRatio || 1;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    canvas.width = Math.floor(width * ratio);
    canvas.height = Math.floor(height * ratio);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    canvas.width = width;
    canvas.height = height;
    redrawUserStrokes(canvas, mode === 'draw' ? userStrokes : [], mode === 'draw' && ghostGuide, emoji);
  };

  useEffect(() => {
    setupCanvas();
    window.addEventListener('resize', setupCanvas);
    return () => window.removeEventListener('resize', setupCanvas);
  }, []);

  useEffect(() => {
    setUserStrokes([]);
    activeStrokeRef.current = null;
    setMarker({ x: 50, y: 50, visible: false });
    const canvas = canvasRef.current;
    if (canvas) redrawUserStrokes(canvas, [], mode === 'draw' && ghostGuide, emoji);
    onStrokesChange([]);
  }, [emoji.id, mode, resetKey]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas && mode === 'draw') redrawUserStrokes(canvas, userStrokes, ghostGuide, emoji);
  }, [ghostGuide, userStrokes, emoji, mode]);

  useEffect(() => {
    if (phase !== 'running' || mode !== 'watch') {
      cancelAnimationFrame(rafRef.current);
      if (phase !== 'running') setMarker((value) => ({ ...value, visible: false }));
      return undefined;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    startedAtRef.current = performance.now();

    const segments = [];
    emoji.strokes.forEach((stroke) => {
      for (let index = 1; index < stroke.points.length; index += 1) {
        segments.push({
          stroke,
          from: stroke.points[index - 1],
          to: stroke.points[index]
        });
      }
    });

    const animate = (now) => {
      const elapsed = (now - startedAtRef.current) / 1000;
      const progress = Math.min(1, elapsed / 14);
      const target = progress * segments.length;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      let currentPoint = null;
      segments.forEach((segment, index) => {
        if (index < Math.floor(target)) {
          drawPath(ctx, [segment.from, segment.to], segment.stroke.color, segment.stroke.width, canvas);
          currentPoint = segment.to;
        } else if (index === Math.floor(target)) {
          const part = target - Math.floor(target);
          const partial = [
            segment.from,
            [
              segment.from[0] + (segment.to[0] - segment.from[0]) * part,
              segment.from[1] + (segment.to[1] - segment.from[1]) * part
            ]
          ];
          drawPath(ctx, partial, segment.stroke.color, segment.stroke.width, canvas);
          currentPoint = partial[1];
        }
      });

      if (currentPoint) {
        setMarker({ x: currentPoint[0] * 100, y: currentPoint[1] * 100, visible: true });
      }

      if (progress < 1 && phase === 'running') {
        rafRef.current = requestAnimationFrame(animate);
      }
    };

    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [phase, mode, emoji, resetKey]);

  const canvasPoint = (event) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const clientX = event.clientX ?? event.touches?.[0]?.clientX;
    const clientY = event.clientY ?? event.touches?.[0]?.clientY;
    return [(clientX - rect.left) / rect.width, (clientY - rect.top) / rect.height];
  };

  const beginDraw = (event) => {
    if (mode !== 'draw' || phase !== 'running') return;
    event.preventDefault();
    const point = canvasPoint(event);
    activeStrokeRef.current = { color: currentColor, width: currentSize, points: [point] };
  };

  const moveDraw = (event) => {
    if (!activeStrokeRef.current || mode !== 'draw' || phase !== 'running') return;
    event.preventDefault();
    const point = canvasPoint(event);
    activeStrokeRef.current.points.push(point);
    const canvas = canvasRef.current;
    redrawUserStrokes(canvas, [...userStrokes, activeStrokeRef.current], ghostGuide, emoji);
  };

  const endDraw = () => {
    if (!activeStrokeRef.current) return;
    const completed = activeStrokeRef.current;
    activeStrokeRef.current = null;
    if (completed.points.length < 2) return;
    const next = [...userStrokes, completed];
    setUserStrokes(next);
    onStrokesChange(next);
  };

  const undo = () => {
    if (!userStrokes.length) return;
    const next = userStrokes.slice(0, -1);
    setUserStrokes(next);
    onStrokesChange(next);
  };

  const clear = () => {
    setConfirmOpen(false);
    setUserStrokes([]);
    onStrokesChange([]);
  };

  useEffect(() => {
    const onKey = (event) => {
      if (event.key.toLowerCase() === 'z' && mode === 'draw') undo();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [userStrokes, mode]);

  return (
    <div className="relative">
      <div className="desk-scene rounded-[2rem] border-[3px] border-ink p-4 shadow-[8px_8px_0_#1B1B1F] sm:p-8">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.18em] text-ink/60">{mode === 'watch' ? 'Watch mode' : 'Draw mode'}</p>
            <h2 className="font-heading text-4xl text-ink">{emoji.name}</h2>
          </div>
          {mode === 'draw' ? (
            <button
              type="button"
              onClick={onFinishEarly}
              disabled={phase !== 'running'}
              className="btn-primary disabled:cursor-not-allowed disabled:opacity-50"
            >
              Finish Early
            </button>
          ) : null}
        </div>

        <div ref={wrapperRef} className="relative mx-auto max-w-4xl rotate-[-1.5deg] rounded-sm border-[3px] border-ink bg-white p-3 shadow-[0_20px_40px_rgba(60,40,10,0.25)]">
          <div className="absolute -left-5 -top-4 z-10 h-9 w-28 -rotate-12 border-2 border-ink bg-sunburst/80" />
          <div className="absolute -right-4 -top-4 z-10 h-9 w-28 rotate-12 border-2 border-ink bg-sunburst/80" />
          <div className="absolute -bottom-4 left-8 z-10 h-9 w-28 rotate-6 border-2 border-ink bg-sunburst/80" />
          <canvas
            ref={canvasRef}
            className="block w-full touch-none rounded-sm bg-white paper-texture"
            onPointerDown={beginDraw}
            onPointerMove={moveDraw}
            onPointerUp={endDraw}
            onPointerCancel={endDraw}
            aria-label="Drawing canvas"
          />
          {mode === 'watch' && marker.visible ? (
            <motion.div
              className="pointer-events-none absolute h-20 w-9 origin-bottom -rotate-12"
              style={{ left: `${marker.x}%`, top: `${marker.y}%`, transform: 'translate(-50%, -90%)' }}
              animate={{ rotate: [-13, -9, -13] }}
              transition={{ duration: 0.5, repeat: Infinity }}
            >
              <svg viewBox="0 0 36 90" className="h-full w-full drop-shadow-[3px_5px_0_rgba(27,27,31,0.25)]">
                <rect x="8" y="7" width="20" height="58" rx="6" fill="#FFFFFF" stroke="#1B1B1F" strokeWidth="4" />
                <rect x="8" y="7" width="20" height="17" rx="6" fill="#FF4D4D" stroke="#1B1B1F" strokeWidth="4" />
                <path d="M11 64h14l-7 19z" fill="#1B1B1F" />
              </svg>
            </motion.div>
          ) : null}
        </div>

        {mode === 'draw' ? (
          <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_auto]">
            <div className="sticker-card bg-paperWhite p-4">
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-2 font-heading text-2xl text-ink">
                  <Brush size={22} /> Markers
                </span>
                {colors.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setCurrentColor(color)}
                    className={`h-11 w-11 rounded-full border-[3px] border-ink transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-sunburst/50 ${
                      currentColor === color ? 'shadow-[3px_3px_0_#1B1B1F]' : ''
                    }`}
                    style={{ backgroundColor: color }}
                    aria-label={`Choose color ${color}`}
                  />
                ))}
                <span className="ml-0 h-8 w-[3px] bg-ink/20 lg:ml-3" />
                {sizes.map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setCurrentSize(size)}
                    className={`grid h-11 min-w-11 place-items-center rounded-full border-[3px] border-ink bg-white px-3 font-black transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-sunburst/50 ${
                      currentSize === size ? 'shadow-[3px_3px_0_#1B1B1F]' : ''
                    }`}
                  >
                    {size}px
                  </button>
                ))}
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <button type="button" onClick={undo} disabled={!userStrokes.length} className="btn-secondary bg-paperWhite disabled:cursor-not-allowed disabled:opacity-50">
                <RotateCcw size={18} /> Undo
              </button>
              <button type="button" onClick={() => setConfirmOpen(true)} className="btn-secondary bg-paperWhite">
                <Trash2 size={18} /> Clear
              </button>
              <button type="button" onClick={() => setGhostGuide((value) => !value)} className="btn-secondary bg-paperWhite">
                {ghostGuide ? <EyeOff size={18} /> : <Eye size={18} />} Ghost Guide
              </button>
            </div>
          </div>
        ) : null}
      </div>
      <ClearConfirm open={confirmOpen} onCancel={() => setConfirmOpen(false)} onConfirm={clear} />
    </div>
  );
});

export default DrawingStage;
