import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Download, ImagePlus, Lightbulb, Play, RotateCcw, Sparkles } from 'lucide-react';
import { useState } from 'react';

function Starburst() {
  const points = Array.from({ length: 24 }, (_, index) => {
    const angle = (Math.PI * 2 * index) / 24;
    const radius = index % 2 === 0 ? 148 : 108;
    return `${160 + Math.cos(angle) * radius},${160 + Math.sin(angle) * radius}`;
  }).join(' ');

  return (
    <svg viewBox="0 0 320 320" className="absolute left-1/2 top-16 h-80 w-80 -translate-x-1/2">
      <polygon points={points} fill="#FFD23F" stroke="#1B1B1F" strokeWidth="8" />
    </svg>
  );
}

function Confetti() {
  const colors = ['#FF4D4D', '#2D7FF9', '#FFD23F', '#2BD17E', '#9B5DE5', '#FF9F1C'];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {Array.from({ length: 40 }, (_, index) => (
        <motion.span
          key={index}
          className="absolute h-3 w-2 rounded-sm"
          style={{
            left: `${(index * 37) % 100}%`,
            top: '-8%',
            backgroundColor: colors[index % colors.length]
          }}
          initial={{ y: -30, rotate: 0, opacity: 0 }}
          animate={{ y: ['0vh', '105vh'], rotate: [0, 220 + index * 11], opacity: [0, 1, 1, 0] }}
          transition={{ duration: 1.8 + (index % 7) * 0.13, delay: (index % 10) * 0.035, ease: 'easeOut' }}
        />
      ))}
    </div>
  );
}

export default function RevealOverlay({
  open,
  emoji,
  dataUrl,
  timeLeft,
  mode,
  onDownload,
  onSave,
  onReplay,
  onTryAnother,
  onSuggest
}) {
  const [suggestion, setSuggestion] = useState('');
  const reduceMotion = useReducedMotion();
  const roundedTime = Math.max(0, timeLeft).toFixed(1);
  const finishedText =
    timeLeft > 0 ? `Finished with ${roundedTime} second(s) to spare!` : mode === 'draw' ? "Time's up!" : 'Finished right on the buzzer!';

  const submitSuggestion = async (event) => {
    event.preventDefault();
    await onSuggest(suggestion);
    setSuggestion('');
  };

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-center overflow-y-auto bg-ink/70 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label="Finished drawing reveal"
        >
          <Confetti />
          <motion.div
            className="relative w-full max-w-5xl py-10 text-center"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
          >
            <motion.div
              initial={{ scale: 0, rotate: -10 }}
              animate={{ scale: reduceMotion ? 1 : [0, 1.2, 1], rotate: 0 }}
              transition={{ duration: 0.55, ease: 'easeOut' }}
            >
              <Starburst />
            </motion.div>

            <motion.h2
              className="relative z-10 font-heading text-[72px] leading-none text-redMarker sm:text-[96px]"
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 260, damping: 13, delay: 0.15 }}
            >
              BOOM!
            </motion.h2>
            <p className="relative z-10 mx-auto mt-1 max-w-2xl rounded-full border-[3px] border-ink bg-paperWhite px-5 py-3 font-heading text-2xl text-ink shadow-[4px_4px_0_#1B1B1F]">
              {finishedText}
            </p>

            <motion.div
              className="relative z-10 mx-auto mt-8 max-w-xl rotate-[3deg] rounded-sm border-[3px] border-ink bg-white p-3 shadow-[0_20px_40px_rgba(60,40,10,0.35)]"
              initial={{ y: 0, scale: 0.8, rotate: -2 }}
              animate={{ y: reduceMotion ? 0 : -40, scale: reduceMotion ? 1 : 1.15, rotate: 3 }}
              transition={{ type: 'spring', stiffness: 180, damping: 16, delay: 0.15 }}
            >
              <div className="absolute -left-5 -top-3 h-8 w-24 -rotate-12 border-2 border-ink bg-sunburst/80" />
              <div className="absolute -bottom-3 -right-5 h-8 w-24 -rotate-12 border-2 border-ink bg-sunburst/80" />
              {dataUrl ? (
                <img src={dataUrl} alt={`${emoji.name} finished drawing`} className="aspect-[4/3] w-full rounded-sm object-contain" />
              ) : (
                <div className="grid aspect-[4/3] place-items-center bg-warmPaper">
                  <Sparkles size={48} />
                </div>
              )}
            </motion.div>

            <div className="relative z-10 mx-auto mt-8 grid max-w-4xl gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <button type="button" onClick={onDownload} className="btn-primary">
                <Download size={19} /> Download PNG
              </button>
              <button type="button" onClick={onSave} className="btn-secondary bg-paperWhite">
                <ImagePlus size={19} /> Save to Gallery
              </button>
              <button type="button" onClick={onReplay} className="btn-secondary bg-paperWhite">
                <RotateCcw size={19} /> Replay
              </button>
              <button type="button" onClick={onTryAnother} className="btn-secondary bg-paperWhite">
                <Play size={19} /> Try Another
              </button>
            </div>

            <form onSubmit={submitSuggestion} className="relative z-10 mx-auto mt-5 flex max-w-2xl flex-col gap-3 rounded-2xl border-[3px] border-ink bg-sunburst p-3 shadow-[4px_4px_0_#1B1B1F] sm:flex-row">
              <label className="sr-only" htmlFor="reveal-suggestion">
                What should I draw next?
              </label>
              <input
                id="reveal-suggestion"
                value={suggestion}
                onChange={(event) => setSuggestion(event.target.value)}
                placeholder="What should I draw next?"
                className="min-h-12 flex-1 rounded-full border-[3px] border-ink bg-white px-5 font-bold outline-none transition focus:ring-4 focus:ring-blueHighlighter/30"
              />
              <button type="submit" className="btn-primary bg-blueHighlighter">
                <Lightbulb size={19} /> Suggest next
              </button>
            </form>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
