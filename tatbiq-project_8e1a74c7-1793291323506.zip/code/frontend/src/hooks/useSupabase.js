import { useMemo } from 'react';
import toast from 'react-hot-toast';
import { isSupabaseConfigured } from '../lib/supabase.js';
import appData from '../data/app-data.json';

const KEYS = {
  drawings: 'edc_drawings',
  ideas: 'edc_ideas',
  voted: 'edc_voted',
  muted: 'edc_muted',
  best: 'edc_best'
};

function readJson(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  window.localStorage.setItem(key, JSON.stringify(value));
}

async function getDrawings() {
  isSupabaseConfigured();
  return readJson(KEYS.drawings, []);
}

async function saveDrawing(drawing) {
  isSupabaseConfigured();
  try {
    const drawings = readJson(KEYS.drawings, []);
    const next = [drawing, ...drawings].slice(0, 24);
    writeJson(KEYS.drawings, next);
    toast.success('Added to My Drawings');
    return next;
  } catch (error) {
    toast.error('Save failed: ' + error.message);
    throw error;
  }
}

async function deleteDrawing(id) {
  isSupabaseConfigured();
  try {
    const drawings = readJson(KEYS.drawings, []);
    const next = drawings.filter((drawing) => drawing.id !== id);
    writeJson(KEYS.drawings, next);
    toast.success('Drawing deleted');
    return next;
  } catch (error) {
    toast.error('Delete failed: ' + error.message);
    throw error;
  }
}

async function getIdeas() {
  isSupabaseConfigured();
  const stored = readJson(KEYS.ideas, null);
  if (Array.isArray(stored)) return stored;
  writeJson(KEYS.ideas, appData.seedIdeas);
  return appData.seedIdeas;
}

async function addIdea(text) {
  isSupabaseConfigured();
  try {
    const ideas = await getIdeas();
    const trimmed = text.trim();
    const duplicate = ideas.some((idea) => idea.text.toLowerCase() === trimmed.toLowerCase());
    if (duplicate) {
      toast.error('That idea is already on the list - vote for it!');
      throw new Error('Duplicate idea');
    }
    const idea = {
      id: 'idea-' + Date.now(),
      text: trimmed,
      votes: 1
    };
    const next = [idea, ...ideas];
    writeJson(KEYS.ideas, next);
    toast.success('Thanks! Idea added');
    return next;
  } catch (error) {
    if (error.message !== 'Duplicate idea') {
      toast.error('Save failed: ' + error.message);
    }
    throw error;
  }
}

async function getVoted() {
  isSupabaseConfigured();
  return readJson(KEYS.voted, []);
}

async function voteIdea(id) {
  isSupabaseConfigured();
  try {
    const ideas = await getIdeas();
    const voted = readJson(KEYS.voted, []);
    if (voted.includes(id)) return { ideas, voted };
    const nextIdeas = ideas.map((idea) => (idea.id === id ? { ...idea, votes: idea.votes + 1 } : idea));
    const nextVoted = [...voted, id];
    writeJson(KEYS.ideas, nextIdeas);
    writeJson(KEYS.voted, nextVoted);
    toast.success('Vote counted');
    return { ideas: nextIdeas, voted: nextVoted };
  } catch (error) {
    toast.error('Vote failed: ' + error.message);
    throw error;
  }
}

async function getMuted() {
  isSupabaseConfigured();
  return readJson(KEYS.muted, false);
}

async function setMuted(value) {
  isSupabaseConfigured();
  writeJson(KEYS.muted, value);
  return value;
}

async function getBest() {
  isSupabaseConfigured();
  return readJson(KEYS.best, {});
}

async function saveBest(emojiId, timeLeft) {
  isSupabaseConfigured();
  try {
    const best = readJson(KEYS.best, {});
    const current = Number(best[emojiId] || 0);
    if (timeLeft > current) {
      const next = { ...best, [emojiId]: timeLeft };
      writeJson(KEYS.best, next);
      toast.success('New best time!');
      return next;
    }
    return best;
  } catch (error) {
    toast.error('Best time failed: ' + error.message);
    throw error;
  }
}

export function useSupabase() {
  return useMemo(
    () => ({
      getDrawings,
      saveDrawing,
      deleteDrawing,
      getIdeas,
      addIdea,
      getVoted,
      voteIdea,
      getMuted,
      setMuted,
      getBest,
      saveBest
    }),
    []
  );
}
