import { motion } from 'framer-motion';
import { Download, Image, Sparkles, Trash2, Trophy } from 'lucide-react';
import toast from 'react-hot-toast';
import appData from '../data/app-data.json';
import { useApp } from '../App';

export default function GalleryPage() {
  const { drawings, deleteDrawing, best } = useApp();

  const download = (drawing) => {
    const link = document.createElement('a');
    link.href = drawing.dataUrl;
    link.download = `emoji-${drawing.emojiName.toLowerCase().replaceAll(' ', '-')}.png`;
    link.click();
    toast.success('Saved!');
  };

  return (
    <div className="min-h-screen bg-warmPaper pt-24">
      <section className="relative overflow-hidden py-14">
        <div className="absolute right-8 top-24 text-blueHighlighter/20"><Sparkles size={100} /></div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-[1fr_0.8fr] lg:items-end">
            <div>
              <p className="eyebrow">My Drawings</p>
              <h1 className="mt-3 font-heading text-6xl leading-none text-ink md:text-8xl">Gallery wall</h1>
              <p className="mt-5 max-w-2xl text-lg font-bold text-ink/70">
                Your last saved PNG drawings live here locally, with best times for every challenge.
              </p>
            </div>
            <div className="sticker-card overflow-hidden bg-paperWhite">
              <img src={appData.images.paper} alt="White paper sketchbook closeup" className="h-56 w-full object-cover" />
            </div>
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {appData.emojis.map((emoji) => (
              <motion.div
                key={emoji.id}
                className="sticker-card bg-paperWhite p-5"
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true, margin: '-80px' }}
                whileHover={{ x: -2, y: -2 }}
              >
                <div className="flex items-center gap-4">
                  <div className="grid h-16 w-16 place-items-center rounded-full border-[3px] border-ink font-heading text-2xl shadow-[3px_3px_0_#1B1B1F]" style={{ backgroundColor: emoji.blob }}>
                    {emoji.preview}
                  </div>
                  <div>
                    <p className="font-heading text-2xl text-ink">{emoji.name}</p>
                    <p className="inline-flex items-center gap-1 font-black text-ink/65">
                      <Trophy size={17} /> {best[emoji.id] ? `${best[emoji.id].toFixed(1)}s best` : 'No best time yet'}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-14 flex items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Saved PNGs</p>
              <h2 className="mt-2 font-heading text-5xl text-ink">Last 8 drawings</h2>
            </div>
          </div>

          {drawings.length ? (
            <motion.div
              className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4"
              initial="hidden"
              animate="show"
              variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
            >
              {drawings.slice(0, 8).map((drawing) => (
                <motion.article
                  key={drawing.id}
                  className="sticker-card overflow-hidden bg-paperWhite"
                  variants={{ hidden: { y: 30, opacity: 0 }, show: { y: 0, opacity: 1, transition: { duration: 0.4 } } }}
                  whileHover={{ x: -2, y: -2 }}
                >
                  <img src={drawing.dataUrl} alt={drawing.emojiName} className="aspect-[4/3] w-full border-b-[3px] border-ink bg-white object-contain" />
                  <div className="p-4">
                    <h3 className="font-heading text-2xl text-ink">{drawing.emojiName}</h3>
                    <p className="font-black text-ink/65">
                      {drawing.mode === 'watch' ? 'Watch mode' : 'Draw mode'} / {Math.max(0, drawing.timeLeft).toFixed(1)}s left
                    </p>
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      <button type="button" onClick={() => download(drawing)} className="btn-secondary justify-center bg-warmPaper px-3 py-2 text-sm">
                        <Download size={16} /> PNG
                      </button>
                      <button type="button" onClick={() => deleteDrawing(drawing.id)} className="btn-primary justify-center px-3 py-2 text-sm">
                        <Trash2 size={16} /> Delete
                      </button>
                    </div>
                  </div>
                </motion.article>
              ))}
            </motion.div>
          ) : (
            <div className="mt-8 grid min-h-80 place-items-center rounded-[2rem] border-[3px] border-dashed border-ink bg-paperWhite p-8 text-center shadow-[6px_6px_0_#1B1B1F]">
              <div>
                <div className="mx-auto grid h-20 w-20 place-items-center rounded-full border-[3px] border-ink bg-sunburst">
                  <Image size={38} />
                </div>
                <h3 className="mt-5 font-heading text-4xl text-ink">No saved drawings yet</h3>
                <p className="mt-2 max-w-md font-bold text-ink/65">Finish a challenge, hit Save to Gallery, and your paper will appear here.</p>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
