import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Clock3, Download, Eye, Lightbulb, MousePointer2, Pencil, Play, Sparkles, ThumbsUp, Timer, Trophy } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import appData from '../data/app-data.json';
import EmojiCard from '../components/EmojiCard';
import { useApp } from '../App';

function WavyDivider({ flip = false }) {
  return (
    <svg className={`block h-12 w-full ${flip ? 'rotate-180' : ''}`} viewBox="0 0 1440 80" preserveAspectRatio="none" aria-hidden="true">
      <path d="M0,32 C180,86 320,0 520,36 C720,74 890,6 1090,36 C1240,58 1340,44 1440,22 L1440,80 L0,80 Z" fill="currentColor" />
    </svg>
  );
}

function PreviewFace({ emoji }) {
  return (
    <div className="relative grid h-20 w-20 place-items-center rounded-full border-[3px] border-ink shadow-[4px_4px_0_#1B1B1F]" style={{ backgroundColor: emoji.blob }}>
      <span className="font-heading text-3xl text-ink">{emoji.preview}</span>
      <span className="absolute bottom-4 h-2 w-8 rounded-full bg-ink" />
    </div>
  );
}

function IdeasSection() {
  const { ideas, voted, addIdea, voteIdea } = useApp();
  const [value, setValue] = useState('');
  const [error, setError] = useState('');

  const submit = async (event) => {
    event.preventDefault();
    const trimmed = value.trim();
    if (trimmed.length < 2 || trimmed.length > 30) {
      setError('Please enter 2-30 characters');
      return;
    }
    try {
      setError('');
      await addIdea(trimmed);
      setValue('');
    } catch (err) {
      setError(err.message === 'Duplicate idea' ? 'That idea is already on the list - vote for it!' : err.message);
    }
  };

  const quickPick = async (text) => {
    setValue(text);
  };

  return (
    <section id="ideas" className="relative overflow-hidden bg-paleYellow py-20">
      <div className="absolute left-6 top-10 text-blueHighlighter/25"><Sparkles size={80} /></div>
      <div className="absolute bottom-10 right-8 text-redMarker/20"><Lightbulb size={90} /></div>

      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.4 }}
        >
          <p className="eyebrow">Community ideas</p>
          <h2 className="mt-3 font-heading text-5xl leading-none text-ink md:text-7xl">What should I draw next?</h2>
          <p className="mt-5 text-lg font-bold text-ink/70">
            Drop a new challenge or vote for the next short-video doodle. Every idea is saved locally in your browser.
          </p>

          <form onSubmit={submit} className="mt-8 rounded-[1.75rem] border-[3px] border-ink bg-paperWhite p-4 shadow-[6px_6px_0_#1B1B1F]">
            <label htmlFor="idea" className="font-heading text-2xl text-ink">Suggest an emoji idea</label>
            <div className="mt-3 flex flex-col gap-3 sm:flex-row">
              <input
                id="idea"
                value={value}
                onChange={(event) => setValue(event.target.value)}
                placeholder="Try Wizard Frog"
                className="min-h-14 flex-1 rounded-full border-[3px] border-ink bg-warmPaper px-5 font-extrabold outline-none transition focus:ring-4 focus:ring-blueHighlighter/30"
              />
              <button type="submit" className="btn-primary">
                Add Idea <ArrowRight size={19} />
              </button>
            </div>
            {error ? <p className="mt-3 font-black text-redMarker">{error}</p> : null}
            <div className="mt-4 flex flex-wrap gap-2">
              {appData.quickPicks.map((pick) => (
                <button
                  key={pick}
                  type="button"
                  onClick={() => quickPick(pick)}
                  className="rounded-full border-2 border-ink bg-sunburst px-4 py-2 text-sm font-black transition hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-redMarker/20"
                >
                  {pick}
                </button>
              ))}
            </div>
          </form>
        </motion.div>

        <motion.div
          className="grid gap-4"
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-80px' }}
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
        >
          {ideas.map((idea, index) => (
            <motion.div
              key={idea.id}
              className="sticker-card flex items-center justify-between gap-4 bg-paperWhite p-4"
              variants={{ hidden: { y: 30, opacity: 0 }, show: { y: 0, opacity: 1, transition: { duration: 0.4 } } }}
              whileHover={{ x: -2, y: -2 }}
            >
              <div className="flex items-center gap-4">
                <div className="grid h-12 w-12 place-items-center rounded-full border-[3px] border-ink bg-blueHighlighter font-heading text-xl text-white">
                  {index + 1}
                </div>
                <div>
                  <p className="font-heading text-2xl text-ink">{idea.text}</p>
                  <p className="font-black text-ink/60">{idea.votes} votes</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => voteIdea(idea.id)}
                disabled={voted.includes(idea.id)}
                className="btn-secondary bg-warmPaper disabled:cursor-not-allowed disabled:bg-goGreen disabled:text-ink"
              >
                <ThumbsUp size={18} /> {voted.includes(idea.id) ? 'Voted' : 'Vote'}
              </button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

export default function HomePage() {
  const { selectedEmoji, setSelectedEmoji, best, startChallenge } = useApp();
  const navigate = useNavigate();
  const reduceMotion = useReducedMotion();
  const { scrollY } = useScroll();
  const heroY = useTransform(scrollY, [0, 700], [0, reduceMotion ? 0 : 90]);

  const headlineWords = ['Can', 'you', 'beat', '15 seconds?'];
  const emojiRows = useMemo(() => appData.emojis, []);

  const start = (mode) => {
    startChallenge(selectedEmoji || appData.emojis[0], mode);
    navigate('/challenge');
  };

  return (
    <>
      <section className="relative flex min-h-[90vh] items-center overflow-hidden pt-24">
        <motion.div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${appData.images.hero})`, y: heroY }}
          aria-hidden="true"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-warmPaper/90 via-warmPaper/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 text-warmPaper"><WavyDivider /></div>

        <div className="relative z-10 mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <motion.div
            className="max-w-4xl"
            initial="hidden"
            animate="show"
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
          >
            <p className="eyebrow">15-second emoji drawing challenge</p>
            <h1 className="mt-5 flex flex-wrap gap-x-4 gap-y-1 font-heading text-6xl leading-[0.9] text-ink sm:text-7xl lg:text-8xl">
              {headlineWords.map((word) => (
                <motion.span
                  key={word}
                  className="relative inline-block"
                  variants={{
                    hidden: { y: 40, rotate: -3, opacity: 0 },
                    show: { y: 0, rotate: 0, opacity: 1, transition: { type: 'spring', stiffness: 320, damping: 18 } }
                  }}
                >
                  {word}
                  {word === '15 seconds?' ? (
                    <motion.svg
                      viewBox="0 0 360 34"
                      className="absolute -bottom-5 left-0 h-8 w-full"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={{ duration: 0.5, delay: 0.48 }}
                    >
                      <motion.path
                        d="M8 22 C88 4 180 33 352 12"
                        fill="none"
                        stroke="#FF4D4D"
                        strokeWidth="12"
                        strokeLinecap="round"
                      />
                    </motion.svg>
                  ) : null}
                </motion.span>
              ))}
            </h1>
            <motion.p
              className="mt-10 max-w-2xl text-xl font-extrabold text-ink/75"
              variants={{ hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } }}
            >
              Pick a challenge, watch the marker race, or grab the digital Sharpie and draw before the giant timer hits zero.
            </motion.p>

            <motion.div
              className="mt-8 flex flex-col gap-3 sm:flex-row"
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 260, damping: 13, delay: 0.7 }}
            >
              <button type="button" onClick={() => start('watch')} className="btn-primary text-lg">
                <Eye size={22} /> Watch It Drawn
              </button>
              <button type="button" onClick={() => start('draw')} className="btn-secondary bg-paperWhite text-lg">
                <Pencil size={22} /> I'll Draw It
              </button>
            </motion.div>
          </motion.div>
        </div>

        <motion.div
          className="absolute bottom-10 left-0 right-0 z-20 overflow-hidden border-y-[3px] border-ink bg-sunburst py-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          <div className="marquee font-heading text-3xl text-ink">
            <span>GO! GO! GO! Laughing Face / Cool Dragon / Rocket Ship / Heart-Eyes / Sleepy Cat / Sunglasses Cool Face / </span>
            <span>GO! GO! GO! Laughing Face / Cool Dragon / Rocket Ship / Heart-Eyes / Sleepy Cat / Sunglasses Cool Face / </span>
          </div>
        </motion.div>
      </section>

      <section className="bg-warmPaper py-12">
        <div className="mx-auto grid max-w-7xl gap-4 px-4 sm:grid-cols-2 sm:px-6 lg:grid-cols-4 lg:px-8">
          {appData.heroStats.map((stat) => (
            <motion.div
              key={stat.label}
              className="sticker-card bg-paperWhite p-5 text-center"
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true, margin: '-80px' }}
              whileHover={{ x: -2, y: -2 }}
            >
              <p className="font-heading text-5xl text-redMarker">{stat.value}</p>
              <p className="mt-1 font-black text-ink/70">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="relative bg-warmPaper py-20">
        <div className="absolute right-6 top-8 rotate-12 text-redMarker/20"><Sparkles size={90} /></div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="eyebrow">Pick your sprint</p>
              <h2 className="mt-3 font-heading text-5xl leading-none text-ink md:text-7xl">Choose an emoji challenge</h2>
            </div>
            <div className="flex gap-3">
              <button
                type="button"
                disabled={!selectedEmoji}
                onClick={() => start('watch')}
                className="btn-primary disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Play size={19} /> Watch It Drawn
              </button>
              <button
                type="button"
                disabled={!selectedEmoji}
                onClick={() => start('draw')}
                className="btn-secondary bg-paperWhite disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Pencil size={19} /> I'll Draw It
              </button>
            </div>
          </div>

          <motion.div
            className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: '-80px' }}
            variants={{ hidden: {}, show: { transition: { staggerChildren: 0.07 } } }}
          >
            {emojiRows.map((emoji) => (
              <motion.div
                key={emoji.id}
                variants={{ hidden: { y: 30, opacity: 0 }, show: { y: 0, opacity: 1, transition: { duration: 0.4 } } }}
              >
                <EmojiCard
                  emoji={emoji}
                  selected={selectedEmoji?.id === emoji.id}
                  bestTime={best[emoji.id]}
                  onSelect={setSelectedEmoji}
                />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      <section className="relative overflow-hidden bg-paleYellow py-20">
        <div className="absolute left-0 right-0 top-0 text-warmPaper"><WavyDivider flip /></div>
        <div className="mx-auto grid max-w-7xl gap-8 px-4 pt-12 sm:px-6 lg:grid-cols-3 lg:px-8">
          {[
            { title: 'Pick', body: 'Choose one of six quick drawing prompts with a mini preview and difficulty.', icon: MousePointer2, image: appData.images.markers },
            { title: 'GO', body: 'The intro counts down, the timer glows, and every tick raises the pressure.', icon: Timer, image: appData.images.timer },
            { title: 'BOOM', body: 'The paper lifts, confetti falls, and your drawing is ready to save or replay.', icon: Download, image: appData.images.sketching }
          ].map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.article
                key={step.title}
                className="sticker-card overflow-hidden bg-paperWhite"
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.4, delay: index * 0.07 }}
                whileHover={{ x: -2, y: -2 }}
              >
                <img src={step.image} alt={step.title} className="h-48 w-full border-b-[3px] border-ink object-cover" />
                <div className="p-6">
                  <div className="mb-4 flex items-center gap-3">
                    <span className="grid h-12 w-12 place-items-center rounded-full border-[3px] border-ink bg-sunburst font-heading text-2xl">{index + 1}</span>
                    <Icon size={30} />
                  </div>
                  <h3 className="font-heading text-4xl text-ink">{step.title}</h3>
                  <p className="mt-2 font-bold text-ink/70">{step.body}</p>
                </div>
              </motion.article>
            );
          })}
        </div>

        <div className="mx-auto mt-14 grid max-w-7xl gap-3 px-4 sm:grid-cols-3 sm:px-6 lg:grid-cols-6 lg:px-8">
          {appData.emojis.map((emoji) => (
            <div key={emoji.id} className="flex justify-center">
              <PreviewFace emoji={emoji} />
            </div>
          ))}
        </div>
      </section>

      <IdeasSection />
    </>
  );
}
