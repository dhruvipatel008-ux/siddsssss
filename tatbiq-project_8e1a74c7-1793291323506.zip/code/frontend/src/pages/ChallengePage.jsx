import { AnimatePresence, motion } from 'framer-motion';
import { Home, Volume2, VolumeX } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import DrawingStage from '../components/DrawingStage';
import RevealOverlay from '../components/RevealOverlay';
import TimerRing from '../components/TimerRing';
import appData from '../data/app-data.json';
import { useApp } from '../App';

function IntroOverlay({ emoji, open }) {
  const [beat, setBeat] = useState('3');

  useEffect(() => {
    if (!open) return undefined;
    setBeat('3');
    const beats = ['3', '2', '1', 'GO!'];
    const timers = beats.map((value, index) => window.setTimeout(() => setBeat(value), index * 700));
    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [open]);

  return (
    <AnimatePresence>
      {open ? (
        <motion.div
          className="fixed inset-0 z-40 grid place-items-center bg-warmPaper/90 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="text-center">
            <motion.p
              className="mx-auto max-w-3xl font-heading text-4xl leading-none text-ink sm:text-6xl"
              initial={{ y: 30, opacity: 0, rotate: -2 }}
              animate={{ y: 0, opacity: 1, rotate: 0 }}
            >
              Can I draw a full {emoji.name} in just 15 seconds?
            </motion.p>
            <motion.div
              key={beat}
              className={`mt-8 font-heading leading-none ${beat === 'GO!' ? 'text-goGreen' : 'text-redMarker'} text-[120px] sm:text-[180px]`}
              initial={{ scale: 2.2, opacity: 0, rotate: -8 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ duration: 0.6, type: 'spring', stiffness: 260, damping: 14 }}
            >
              {beat}
            </motion.div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default function ChallengePage() {
  const {
    selectedEmoji,
    setSelectedEmoji,
    mode,
    setMode,
    phase,
    setPhase,
    timeLeft,
    setTimeLeft,
    muted,
    setMutedPreference,
    saveDrawing,
    saveBest,
    addIdea
  } = useApp();

  const navigate = useNavigate();
  const stageRef = useRef(null);
  const audioRef = useRef(null);
  const timerRef = useRef(null);
  const lastTickRef = useRef(15);
  const [resetKey, setResetKey] = useState(0);
  const [finalDataUrl, setFinalDataUrl] = useState('');
  const [finalTime, setFinalTime] = useState(0);
  const [strokes, setStrokes] = useState([]);

  const emoji = selectedEmoji || appData.emojis[0];

  const tick = () => {
    if (muted) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!audioRef.current) audioRef.current = new AudioContext();
      const ctx = audioRef.current;
      const oscillator = ctx.createOscillator();
      const gain = ctx.createGain();
      oscillator.type = 'square';
      oscillator.frequency.value = 880;
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      oscillator.connect(gain);
      gain.connect(ctx.destination);
      oscillator.start();
      oscillator.stop(ctx.currentTime + 0.08);
    } catch {
      toast.error('Audio unavailable in this browser');
    }
  };

  const endRound = (value) => {
    const clamped = Math.max(0, value);
    setFinalTime(clamped);
    window.setTimeout(() => {
      const dataUrl = stageRef.current?.getDataUrl() || '';
      setFinalDataUrl(dataUrl);
      setPhase('reveal');
      saveBest(emoji.id, clamped);
    }, 40);
  };

  const beginRound = () => {
    window.cancelAnimationFrame(timerRef.current);
    setFinalDataUrl('');
    setFinalTime(0);
    setTimeLeft(15);
    setResetKey((value) => value + 1);
    setPhase('intro');
    window.setTimeout(() => {
      lastTickRef.current = 15;
      setTimeLeft(15);
      setPhase('running');
    }, 3000);
  };

  useEffect(() => {
    if (!selectedEmoji) setSelectedEmoji(appData.emojis[0]);
    if (!mode) setMode('watch');
  }, []);

  useEffect(() => {
    beginRound();
    return () => window.cancelAnimationFrame(timerRef.current);
  }, [emoji.id, mode]);

  useEffect(() => {
    if (phase !== 'running') return undefined;
    const started = performance.now();
    const run = (now) => {
      const elapsed = (now - started) / 1000;
      const next = Math.max(0, 15 - elapsed);
      setTimeLeft(next);
      const whole = Math.ceil(next);
      if (whole < lastTickRef.current && whole >= 0) {
        lastTickRef.current = whole;
        tick();
      }
      if (next <= 0) {
        endRound(0);
        return;
      }
      timerRef.current = requestAnimationFrame(run);
    };
    timerRef.current = requestAnimationFrame(run);
    return () => window.cancelAnimationFrame(timerRef.current);
  }, [phase, muted]);

  useEffect(() => {
    const onKey = (event) => {
      if (event.code === 'Space' && phase === 'reveal') {
        event.preventDefault();
        beginRound();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase, emoji.id, mode]);

  const finishEarly = () => {
    if (phase !== 'running') return;
    window.cancelAnimationFrame(timerRef.current);
    endRound(timeLeft);
  };

  const download = () => {
    const dataUrl = finalDataUrl || stageRef.current?.getDataUrl();
    if (!dataUrl) {
      toast.error('Download failed: no drawing found');
      return;
    }
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `emoji-${emoji.name.toLowerCase().replaceAll(' ', '-')}.png`;
    link.click();
    toast.success('Saved!');
  };

  const save = async () => {
    const dataUrl = finalDataUrl || stageRef.current?.getDataUrl();
    if (!dataUrl) {
      toast.error('Save failed: no drawing found');
      return;
    }
    await saveDrawing({
      id: 'drawing-' + Date.now(),
      emojiId: emoji.id,
      emojiName: emoji.name,
      dataUrl,
      timeLeft: finalTime,
      mode,
      createdAt: new Date().toISOString()
    });
  };

  const suggest = async (text) => {
    const trimmed = text.trim();
    if (trimmed.length < 2 || trimmed.length > 30) {
      toast.error('Please enter 2-30 characters');
      return;
    }
    await addIdea(trimmed);
  };

  const tryAnother = () => {
    setPhase('idle');
    navigate('/');
    window.setTimeout(() => document.querySelector('#ideas')?.previousElementSibling?.scrollIntoView({ behavior: 'smooth' }), 60);
  };

  return (
    <div className="min-h-screen bg-warmPaper pt-24">
      <IntroOverlay emoji={emoji} open={phase === 'intro'} />

      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-6 grid gap-4 lg:grid-cols-[1fr_auto_1fr] lg:items-center">
          <div className="sticker-card bg-paperWhite p-4">
            <p className="eyebrow">Current challenge</p>
            <h1 className="font-heading text-4xl text-ink sm:text-5xl">{emoji.name}</h1>
          </div>

          <div className="mx-auto">
            <TimerRing timeLeft={timeLeft} />
          </div>

          <div className="flex flex-wrap justify-start gap-3 lg:justify-end">
            <button
              type="button"
              onClick={() => setMutedPreference(!muted)}
              className="btn-secondary bg-paperWhite"
              aria-label={muted ? 'Unmute timer' : 'Mute timer'}
            >
              {muted ? <VolumeX size={20} /> : <Volume2 size={20} />} {muted ? 'Unmute' : 'Mute'}
            </button>
            <button type="button" onClick={() => navigate('/')} className="btn-secondary bg-paperWhite">
              <Home size={20} /> Picker
            </button>
          </div>
        </div>

        <DrawingStage
          ref={stageRef}
          emoji={emoji}
          mode={mode}
          phase={phase}
          resetKey={resetKey}
          onFinishEarly={finishEarly}
          onStrokesChange={setStrokes}
        />

        {mode === 'draw' && phase === 'running' && !strokes.length ? (
          <p className="mt-5 rounded-2xl border-[3px] border-ink bg-paleYellow p-4 text-center font-black shadow-[4px_4px_0_#1B1B1F]">
            Canvas is live. Draw with mouse, touch, or pen. Press Z to undo.
          </p>
        ) : null}
      </section>

      <RevealOverlay
        open={phase === 'reveal'}
        emoji={emoji}
        dataUrl={finalDataUrl}
        timeLeft={finalTime}
        mode={mode}
        onDownload={download}
        onSave={save}
        onReplay={beginRound}
        onTryAnother={tryAnother}
        onSuggest={suggest}
      />
    </div>
  );
}
