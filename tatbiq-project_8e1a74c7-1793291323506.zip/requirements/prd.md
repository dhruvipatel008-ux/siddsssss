# Product Requirements Document (PRD) for Emoji Draw Challenge

## 1. Introduction
Emoji Draw Challenge is an interactive web experience built from the "15-Second Emoji Drawing Challenge" short-video concept. The visitor sits in the creator's seat: a top-down view of a sheet of paper and a marker, a 15-second countdown, and a chosen emoji to draw before time runs out. The experience mirrors the original script: a "GO!" intro, a ticking timer while lines turn into a character, and a "BOOM!" reveal with the time left over and the closing question "What should I draw next?"

The app has two parts. First, a **Watch mode** in which a marker automatically draws a pre-authored emoji (laughing-crying face, cool dragon, and others) stroke by stroke on a canvas, in sync with the 15-second timer, so the viewer sees the satisfying demonstration. Second, a **Draw mode** in which the player draws on the canvas themselves against the same clock. Both modes end on the same reveal screen. A "What should I draw next?" voting list stores the viewer's suggestion locally.

Target users are short-form video fans, kids, and casual players who want a quick, satisfying, shareable creative moment. The value proposition is a 20-second loop that is fun, tactile, and instantly replayable.

## 2. Features

### Core Features:
- **Emoji Picker:** 6 emoji challenges to choose from: Laughing-Crying Face, Cool Dragon, Sunglasses Cool Face, Heart-Eyes, Rocket Ship, Sleepy Cat. Each is a card with a mini preview.
- **Intro Sequence (0:00-0:03):** Overlay text "Can I draw a full {emoji name} in just 15 seconds? GO!" with a 3-2-1 beat, then the timer starts.
- **15-Second Timer (0:03-0:15 equivalent):** Large circular countdown ring plus numeric display, with a tick sound each second (Web Audio API oscillator, no audio files) and a mute toggle. The ring turns from green to amber to red as time runs low.
- **Watch Mode (auto-draw):** Canvas animates a marker (SVG marker cursor graphic) tracing pre-defined stroke paths with a requestAnimationFrame loop, speed-scaled so the drawing finishes with 1 second to spare. Strokes are drawn in layers: outline, then fill, then details.
- **Draw Mode (play):** The player draws freehand with mouse or touch on the canvas. Controls are a 6-color marker palette, 3 brush sizes, undo, and clear. A faint "ghost guide" of the emoji can be toggled on.
- **Top-Down Desk Scene:** The canvas sits on a desk surface with a marker, paper texture, and subtle shadow, giving the top-down view.
- **Reveal Screen (0:15-0:20):** The finished drawing is lifted and scaled up with a "BOOM! Finished with {n} second(s) to spare!" message (Draw mode shows the real time left, or "Time's up!" if the clock hit zero). Confetti burst on completion.
- **"What should I draw next?" Suggestions:** A small input plus 6 quick-pick chips. Submitted ideas are saved locally and shown in a "Community Ideas" list with vote counts, seeded with 8 entries.
- **Best Times & Gallery:** Finished drawings are saved as PNG data URLs. A "My Drawings" strip shows the last 8 with the emoji name and time left.
- **Navigation, Layout and Responsive Design:** Header with logo, Play, Gallery and Ideas links, plus a footer.

### Additional Features:
- Download PNG button on the reveal screen.
- Replay and "Try another emoji" buttons.
- Keyboard shortcut: Space starts, Z undoes.

## 3. User Stories
- As a viewer, I want to watch a marker draw a dragon emoji in 15 seconds so that I get the satisfying demonstration.
- As a player, I want to draw my own emoji against the clock so that I can take the challenge myself.
- As a player, when I click GO!, I want the countdown and ticking sound to start so that the pressure feels real.
- As a fan, I want to suggest the next emoji to draw so that I can influence future challenges.
- As a creator, I want to download my finished drawing so that I can share it.

## 3.5. Interactive Elements

**Button Specifications:**
- Emoji Card (picker): Click → selects emoji → highlights card → enables the Watch and Draw buttons → On error: none.
- Watch It Drawn: Opens the Challenge stage in Watch mode → shows the intro overlay "Can I draw a full {name} in just 15 seconds? GO!" → after 3 s starts the timer and the auto-draw.
- I'll Draw It: Opens the Challenge stage in Draw mode → intro overlay → timer starts → canvas accepts input only while the timer runs.
- Mute/Unmute: Toggles tick audio and saves the choice to localStorage `edc_muted`.
- Color swatch / Brush size: Sets the current stroke color or width (4/8/14 px) → applies to the next stroke.
- Undo: Removes the last stroke and redraws the canvas → disabled when there are no strokes.
- Clear: Opens a small centered confirm "Clear your drawing?" → Confirm wipes the canvas → Cancel closes.
- Ghost Guide toggle: Shows or hides the faint emoji outline at 15% opacity.
- Finish Early (Draw mode): Ends the round immediately → reveal shows the real time left.
- Download PNG: Exports the canvas via toDataURL → triggers a download named `emoji-{name}.png` → toast "Saved!".
- Save to Gallery: Stores the drawing in localStorage → toast "Added to My Drawings".
- Replay: Resets the timer and canvas and re-runs the intro.
- Try Another Emoji: Returns to the picker.

**Form Specifications:**
- Suggest Next Emoji form: Field: text (2-30 chars) → Validates non-empty, trimmed, no duplicates (case-insensitive) → Submit: adds the idea with 1 vote at the top of the list, toast "Thanks! Idea added" → Errors: "Please enter 2-30 characters" / "That idea is already on the list - vote for it!"
- Vote button on an idea: Increments the count once per idea per browser (tracked in localStorage) → button becomes "Voted".

**Modal Specifications:**
- Clear Confirm: Triggered by Clear → shows Confirm/Cancel → closes on either action or Esc.
- Reveal Overlay: Triggered when the timer ends or on Finish Early → shows the lifted drawing, BOOM message, time left, and actions (Download, Save, Replay, Suggest next) → closes with Replay or Try Another.

## 4. Design & Styling

### 4.0 Design Direction
- **Direction:** "Sharpie Sunrise"
- **Why it fits:** A bright, tactile desk-top world of warm paper, bold marker colors and sticker-like UI that makes a 15-second doodle feel like a playful, high-energy short-video moment, with a glowing hero timer as the one thing you cannot ignore.
- **Signature elements (developer MUST implement all):**
  1. **Top-down desk scene:** The stage sits on a wood-grain-tinted desk (`bg-[#E9D8BF]` with a subtle repeating-linear-gradient grain). The paper is a white `rounded-sm` sheet with a soft shadow (`shadow-[0_20px_40px_rgba(60,40,10,0.25)]`), slightly rotated (`rotate-[-1.5deg]`), with tape strips at the corners.
  2. **Giant marker-ring timer:** A 160px SVG circular countdown with a stroke-dasharray ring in a thick 14px rounded stroke, a Lilita One numeral at center, and color shifts green → amber → red. In the last 3 seconds it pulses (scale 1 → 1.12) and shakes slightly.
  3. **Sticker UI:** Cards and buttons have a 3px `#1B1B1F` border, a hard offset shadow (`shadow-[4px_4px_0_#1B1B1F]`), and `rounded-2xl`; on hover they translate by (-2px,-2px) and the shadow grows to 6px.
  4. **Signature moment, the BOOM reveal:** On finish, the paper lifts (translateY -40px, scale 1.15, rotate 3deg) while a comic-burst SVG star (yellow `#FFD23F`, jagged edge) behind it pops in with "BOOM!" in 96px Lilita One text, plus 40 confetti pieces.
  5. **Marker cursor:** In Watch mode a top-down SVG marker (colored cap, body, tip) follows the drawing point with a slight tilt, leaving a trail of ink.

### 4.1 Color Palette
- Primary Color: #FF4D4D (Marker Red)
- Secondary Color: #2D7FF9 (Highlighter Blue)
- Accent Color: #FFD23F (Sunburst Yellow)
- Background Color: #FFF6E5 (Warm Paper)
- Text Color: #1B1B1F (Ink Black)
- Surface/Card Color: #FFFFFF (Paper White)
- Supporting: #2BD17E (Go Green), #FF9F1C (Amber Warning), #9B5DE5 (Grape Marker)

### 4.2 Typography
- Heading Font: 'Lilita One'
- Body Font: 'Nunito'
- Load both via a Google Fonts @import at the top of index.css and set :root variables --font-heading and --font-body.

### 4.3 Visual Style
- Sections use `py-20` with alternating warm paper (#FFF6E5) and a pale yellow (#FFEFC2) background, separated by a hand-drawn wavy SVG divider.
- All cards are sticker-style: 3px ink border, offset hard shadow, `rounded-2xl`.
- Buttons are `rounded-full` and bold, with the primary in Marker Red and white text; hover lifts them with a slight wiggle.
- Decorative doodles (stars, squiggles, sparkles) in accent colors are scattered in section corners at low opacity.
- Emoji previews are large (text-6xl) on tinted circular blobs.

### 4.4 Page Header / Hero
SHOWCASE - full-screen hero, 90vh. The first Section 6 image (top-down marker drawing on a desk) is the background, with a warm paper-colored gradient overlay (`from-[#FFF6E5]/90 via-[#FFF6E5]/60 to-transparent`). The headline "Can you beat 15 seconds?" is oversized (text-7xl/8xl Lilita One) with a marker-underline SVG under "15 seconds". Two CTAs: "Watch It Drawn" and "I'll Draw It". The navigation is transparent with backdrop-blur. Below the headline, a marquee strip of emoji and "GO! GO! GO!" scrolls continuously. A credibility band shows 6 emoji challenges, 15 seconds, 1 second to spare, and 4.9 fun rating.

### 4.6 Animation Choreography (framer-motion is PREINSTALLED - the developer MUST use it)
- **Hero entrance:** Headline words spring in one by one (stiffness 320, damping 18, stagger 0.08s, from y:40 and rotate:-3deg). The underline draws via pathLength over 0.5s. CTAs pop in at 0.7s (scale 0.6 → 1, bouncy). The marquee fades in last.
- **Scroll reveals:** whileInView with y:30 → 0 and a quick 0.4s pop, 0.07s stagger on emoji cards, `once: true`, viewport margin -80px.
- **Hover micro-interactions:** Cards move (-2,-2) with a growing hard shadow; buttons wiggle (rotate ±2deg) with whileTap scale 0.94; emoji previews bounce (y:-6) in a spring.
- **Special moments:** (1) The intro overlay shows "3-2-1-GO!" with each number scaling from 2.2 to 1 in 0.6s, and GO! bursting in green. (2) The BOOM reveal runs the paper-lift sequence over 0.7s with a spring, a starburst pop-in (scale 0 → 1.2 → 1), and confetti falling with randomized rotation. (3) The timer ring pulses and shakes in the last 3 seconds.

## 5. Technical Implementation

### 5.1 Directory Structure
```
/src
  - App.jsx
  - main.jsx
  - index.css
  - components/
    - Layout.jsx
    - DrawingStage.jsx
    - EmojiCard.jsx
    - RevealOverlay.jsx
  - pages/
    - HomePage.jsx
    - ChallengePage.jsx
    - GalleryPage.jsx
  - hooks/
    - useSupabase.js
  - data/
    - app-data.json
/index.html
```

### 5.2 Data Persistence
- **Data Layer:** needed via /src/hooks/useSupabase.js
- **Authentication:** not needed (localStorage-only)
- **LocalStorage Keys:**
  - `edc_drawings`: Array of saved drawings (id, emojiId, dataUrl, timeLeft, mode, createdAt)
  - `edc_ideas`: Community idea list with vote counts
  - `edc_voted`: IDs of ideas the user has voted on
  - `edc_muted`: Sound mute preference
  - `edc_best`: Best (most seconds to spare) per emoji
- **JSON File Locations:**
  - `/src/data/app-data.json`: Emoji definitions (id, name, preview emoji, stroke paths as normalized point arrays with color and width, difficulty), seed community ideas, and hero stats (imported as ES modules, never fetched from public/)
- **Requires Database:** false (client-side Supabase when configured)

### 5.3 State Management
- Use React Context API for global state (defined in App.jsx).
- **Global State Structure:**
  - `selectedEmoji`: Currently chosen emoji object
  - `mode`: 'watch' | 'draw'
  - `phase`: 'idle' | 'intro' | 'running' | 'reveal'
  - `timeLeft`: Seconds remaining (float, 15 → 0)
  - `strokes`: Array of user strokes (for undo)
  - `muted`: Boolean
  - `drawings`, `ideas`: Persisted lists via useSupabase
- **Component Access:** Components use a `useApp()` context hook. The timer runs in ChallengePage with requestAnimationFrame and updates context.

### 5.4 Component Architecture
- **App**: Router (Home, Challenge, Gallery), context provider, and font and global setup.
- **Layout**: Transparent blur header, nav links (Play, Gallery, Ideas), mobile menu, footer, and toast container.
- **DrawingStage**: Canvas on the desk scene. Handles auto-draw playback along stroke paths, freehand pointer events, the marker graphic, ghost guide, palette, brush, undo and clear, and PNG export.
- **EmojiCard**: Reusable sticker card with a preview, name, difficulty, best time, and select state.
- **RevealOverlay**: BOOM reveal with the lifted paper, starburst, confetti, time-left message, and actions.
- **HomePage**: Hero, marquee strip, stats band, emoji picker grid, "How it works" steps (1 Pick, 2 GO, 3 BOOM), and the community ideas section with the suggest form and votes (inline).
- **ChallengePage**: Intro overlay, timer ring, tick audio (Web Audio), mode logic, and the stage plus reveal composition.
- **GalleryPage**: "My Drawings" grid with download and delete, plus best times per emoji.
- **useSupabase.js**: Unified data hook for CRUD on drawings and ideas (localStorage fallback).

**Component Hierarchy:**
```
App
 ├─ Layout
 │   ├─ HomePage
 │   │   └─ EmojiCard
 │   ├─ ChallengePage
 │   │   ├─ DrawingStage
 │   │   └─ RevealOverlay
 │   └─ GalleryPage
```

## 6. Images & Assets
IMAGE_SEARCH_CRITERIA: top-down marker drawing desk, colorful markers flat lay, hand sketching cartoon character, white paper sketchbook closeup, stopwatch timer on desk

1. [Top-down marker drawing on desk (hero)](https://images.unsplash.com/photo-1789289779053-5dc4b3fbf727?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5NTEwMDV8MHwxfHNlYXJjaHwxfHx0b3AtZG93biUyMG1hcmtlciUyMGRyYXdpbmclMjBkZXNrfGVufDF8MHx8fDE3OTMyOTA5MDV8MA&ixlib=rb-4.1.0&q=80&w=1080)
2. [Colorful markers flat lay](https://images.unsplash.com/photo-1643029184678-31017fa169d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5NTEwMDV8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG1hcmtlcnMlMjBmbGF0JTIwbGF5fGVufDF8MHx8fDE3OTMyOTA5MDd8MA&ixlib=rb-4.1.0&q=80&w=1080)
3. [Hand sketching cartoon character](https://images.unsplash.com/photo-1608804375269-d077e2a2adaa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5NTEwMDV8MHwxfHNlYXJjaHwxfHxoYW5kJTIwc2tldGNoaW5nJTIwY2FydG9vbiUyMGNoYXJhY3RlcnxlbnwxfDB8fHwxNzkzMjkwOTA3fDA&ixlib=rb-4.1.0&q=80&w=1080)
4. [White paper sketchbook closeup](https://images.unsplash.com/photo-1551127481-7fe06b8683c5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5NTEwMDV8MHwxfHNlYXJjaHwxfHx3aGl0ZSUyMHBhcGVyJTIwc2tldGNoYm9vayUyMGNsb3NldXB8ZW58MXwwfHx8MTc5MzI5MDkxMXww&ixlib=rb-4.1.0&q=80&w=1080)
5. [Stopwatch timer on desk](https://images.unsplash.com/photo-1620912189866-474843ba5c14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5NTEwMDV8MHwxfHNlYXJjaHwxfHxzdG9wd2F0Y2glMjB0aW1lciUyMG9uJTIwZGVza3xlbnwxfDB8fHwxNzkzMjkwOTE0fDA&ixlib=rb-4.1.0&q=80&w=1080)